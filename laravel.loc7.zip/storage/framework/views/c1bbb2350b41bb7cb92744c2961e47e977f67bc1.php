<?php
    $message = $type = null;

    if(session()->has('success')){
        $message = session()->get('success');
        $type = "primary";
    }

    if(session()->has('error')){
        $message = session()->get('error');
        $type = "danger";
    }
?>

<?php if(!is_null($type) && !is_null($message)): ?>
    <div class="alert alert-<?php echo e($type); ?>" role="alert">
        <?php echo e($message); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e($error); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH D:\OSPanel\domains\laravel.loc\resources\views/inc/message.blade.php ENDPATH**/ ?>