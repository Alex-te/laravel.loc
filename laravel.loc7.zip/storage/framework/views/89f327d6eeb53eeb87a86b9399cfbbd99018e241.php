<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('home')); ?>">Главная</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.index')); ?>"> Админка</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.categories')); ?>"> Категории</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.news')); ?>"> Новости</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.news_sources_show')); ?>"> Источники новостей</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.test1')); ?>"> Скачать изображение</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.test2')); ?>"> Скачать новости</a></li>
<?php /**PATH D:\OSPanel\domains\laravel.loc\resources\views/admin/menu.blade.php ENDPATH**/ ?>