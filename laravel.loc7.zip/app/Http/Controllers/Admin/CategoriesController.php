<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Category\CreateRequest;
use App\Http\Requests\Category\UpdateRequest;
use App\Models\Categories;
use App\Queries\CategoriesQueryBuilder;
use Illuminate\Http\Request;

class CategoriesController extends Controller
{

    function CategoriesShow(CategoriesQueryBuilder $builder)
    {
        return view('admin.categories', [
            'categories' => $builder->getCategories()
        ]);
    }

    function CategoryCreate(CreateRequest $request, CategoriesQueryBuilder $builder)
    {

        $news = $builder->insert($request->validated());
        if (!empty($news)) {
            return redirect()->route('admin.categories')
                ->with('success', __('messages.admin.categories.create.success'));
        } else {
            return redirect()->back()
                ->with('error', __('messages.admin.categories.create.error'));
        }
    }

    function CategorySingle(CategoriesQueryBuilder $builder, $id)
    {
        return view('admin.category', [
            'category' => $builder->getCategoryById($id)
        ]);
    }

    function CategoryUpdate(UpdateRequest $request, CategoriesQueryBuilder $builder, $id)
    {
        if ($builder->update($id, $request->validated())) {
            return redirect()->route('admin.categories')
                ->with('success', __('messages.admin.categories.update.success'));
        } else {
            return redirect()->back()
                ->with('error', __('messages.admin.categories.update.error'));
        }
    }

    function CategoryRemove(CategoriesQueryBuilder $builder, $id)
    {
        if ($builder->remove($id)) {
            return redirect()->route('admin.categories')
                ->with('success', __('messages.admin.categories.remove.success'));
        } else {
            return redirect()->back()
                ->with('error',  __('messages.admin.categories.remove.error'));
        }
    }
}
