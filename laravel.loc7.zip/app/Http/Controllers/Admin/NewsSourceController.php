<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\NewsSource\CreateRequest;
use App\Http\Requests\NewsSource\UpdateRequest;
use App\Queries\NewsSourcesQueryBuilder;
use Illuminate\Http\Request;

class NewsSourceController extends Controller
{

    function NewsSourcesShow(NewsSourcesQueryBuilder $builder)
    {
        return view('admin.news_sources_show', ['sources' => $builder->getNewsSources()]);
    }


    function NewsSourceCreate(CreateRequest $request, NewsSourcesQueryBuilder $builder)
    {
        $newsSourse = $builder->insert($request->validated());
        if (!empty($newsSourse)) {
            return redirect()->route('admin.news_sources_show', [$newsSourse->id])
                ->with('success', __('messages.admin.news_sources.create.success'));
        } else {
            return redirect()->back()
                ->with('error',  __('messages.admin.news_sources.create.error'));
        }
    }

    function NewsSourceUpdate(UpdateRequest $request, NewsSourcesQueryBuilder $builder, $id)
    {
        if ($builder->update($id, $request->validated())) {
            return redirect()->route('admin.news_sources_show')
                ->with('success',  __('messages.admin.news_sources.update.success'));
        } else {
            return redirect()->back()
                ->with('error', __('messages.admin.news_sources.update.error'));
        }
    }

    function NewsSourcesSingle(NewsSourcesQueryBuilder $builder, $id)
    {
        return view('admin.news_source', [
            'news_source' => $builder->getNewsSourceById($id)
        ]);
    }

    function NewsSourceRemove(NewsSourcesQueryBuilder $builder, $id)
    {
        if ($builder->remove($id)) {
            return redirect()->route('admin.news_sources_show')
                ->with('success',  __('messages.admin.news_sources.remove.success'));
        } else {
            return redirect()->back()
                ->with('error', __('messages.admin.news_sources.remove.error'));
        }
    }
}
