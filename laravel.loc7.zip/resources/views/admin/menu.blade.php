<li class="nav-item"><a class="nav-link"  href="{{ route('home')}}">Главная</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.index')}}"> Админка</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.categories')}}"> Категории</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.news')}}"> Новости</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.news_sources_show')}}"> Источники новостей</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.test1')}}"> Скачать изображение</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.test2')}}"> Скачать новости</a></li>
