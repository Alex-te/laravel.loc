@extends('layouts.main')

@section('title')
    @parent | Добавить новость@endsection

@section('menu')
    @include('admin.menu')
@endsection

@section('content')
<h2>Добавить новость</h2>
<form action="post">
    <div class="mb-3">
        <label for="title" class="form-label">Заголовок</label>
        <input type="text" class="form-control" name="title" id="title">
    </div>
    <div  class="mb-3">
        <label class="form-check-label" for="news_text">Описание</label>
        <textarea name="news_text" class="form-control" id="news_text"></textarea>
    </div>
    <div  class="mb-3">
        <label class="form-check-label" for="short_news">Краткое описание</label>
        <input type="text" class="form-control" name="short_news" id="short_news">
    </div>
    <button class="btn btn-primary" type="submit">Добавить</button>
</form>
@include('back')
@endsection
