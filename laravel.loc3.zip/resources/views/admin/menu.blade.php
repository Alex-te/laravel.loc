<li class="nav-item"><a class="nav-link"  href="{{ route('home')}}">Главная</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.index')}}"> Админка</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.add_news')}}"> Добавить новость</a></li>
