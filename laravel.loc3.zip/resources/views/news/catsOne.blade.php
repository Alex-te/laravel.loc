@extends('layouts.main')

@section('title')
    @parent | Категория - "{{ $category_name['title'] }}"@endsection

@section('menu')
    @include('menu')
@endsection

@section('content')
<h2> {{ $category_name['title'] }}</h2>
@foreach ($categories as $item)
        <a href="{{ route('news.newsOne', [$category_name['slug'], $item['id']]) }}">{{ $item['title'] }}</a> </br>
@endforeach

@include('back')
@endsection
