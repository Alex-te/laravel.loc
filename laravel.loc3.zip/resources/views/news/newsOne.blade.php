@extends('layouts.main')

@section('title')
    @parent | Новость - "{{ $news['title'] }}"@endsection

@section('menu')
    @include('menu')
@endsection

@section('content')
<h2> {{ $news['title'] }}</h2>
<p> {{ $news['text'] }}</p>

@include('back')
@endsection


