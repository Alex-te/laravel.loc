<li class="nav-item"><a class="nav-link" href="{{ route('home')  }}">Главная</a></li>
<li class="nav-item"><a class="nav-link" href="{{ route('news.categories')}}">Категории новостей</a></li>
<li class="nav-item"><a class="nav-link" href="{{ route('admin.index') }}">Админка</a></li>
<li class="nav-item"><a class="nav-link" href="{{ route('auth') }}">Авторизация</a></li>

