<li class="nav-item"><a class="nav-link" href="<?php echo e(route('home')); ?>">Главная</a></li>
<li class="nav-item"><a class="nav-link" href="<?php echo e(route('news.categories')); ?>">Категории новостей</a></li>
<li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.index')); ?>">Админка</a></li>
<li class="nav-item"><a class="nav-link" href="<?php echo e(route('auth')); ?>">Авторизация</a></li>

<?php /**PATH D:\OSPanel\domains\laravel.loc\resources\views/menu.blade.php ENDPATH**/ ?>