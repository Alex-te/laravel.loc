<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('home')); ?>">Главная</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.index')); ?>"> Админка</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.add_news')); ?>"> Добавить новость</a></li>
<?php /**PATH D:\OSPanel\domains\laravel.loc\resources\views/admin/menu.blade.php ENDPATH**/ ?>