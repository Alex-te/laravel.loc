<?php $__env->startSection('title'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> | Добавить новость<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h2>Добавить новость</h2>
<form action="post">
    <div class="mb-3">
        <label for="title" class="form-label">Заголовок</label>
        <input type="text" class="form-control" name="title" id="title">
    </div>
    <div  class="mb-3">
        <label class="form-check-label" for="news_text">Описание</label>
        <textarea name="news_text" class="form-control" id="news_text"></textarea>
    </div>
    <div  class="mb-3">
        <label class="form-check-label" for="short_news">Краткое описание</label>
        <input type="text" class="form-control" name="short_news" id="short_news">
    </div>
    <button class="btn btn-primary" type="submit">Добавить</button>
</form>
<?php echo $__env->make('back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\laravel.loc\resources\views/admin/add_news.blade.php ENDPATH**/ ?>