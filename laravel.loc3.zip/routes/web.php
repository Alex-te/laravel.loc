<?php

use App\Http\Controllers\Admin\IndexController as AdminIndexController;
use App\Http\Controllers\HomeContraller;
use App\Http\Controllers\News\CategoriesController;
use App\Http\Controllers\News\NewsController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [HomeContraller::class, 'index'])->name('home');


Route::prefix('news')
    ->group(function () {
Route::get('/categories', [CategoriesController::class, 'index'])
    ->name('news.categories');


Route::get('/categories/{slug}', [CategoriesController::class, 'show'])
//    ->where('id', '[0-9]+')
    ->name('news.catsOne');

Route::get('/news', [NewsController::class, 'index'])->name('news');

Route::get('/{slug}/{id}', [NewsController::class, 'show'])
    ->where('category_id', '[0-9]+')
    ->where('id', '[0-9]+')
    ->name('news.newsOne');
    });


Route::name('admin.')
    ->prefix('admin')
//    ->namespace('Admin')
    ->group(function () {
        Route::get('/', [AdminIndexController::class, 'index'])->name('index');
        Route::get('/add_news', [AdminIndexController::class, 'add_news'])->name('add_news');
    });


Route::view('/about', 'about')->name('about');

Route::view('/auth', 'auth')->name('auth');

//
//Route::get('news/{id}', function ($id = null) {
//    return view('/news');
//})->where('id', '[0-9]+')->name('news');
//
//Route::fallback(function (){ // должна быть последним
//    return view('404');
//});


Auth::routes();

//Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
