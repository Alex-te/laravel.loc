<?php

namespace App\Models;

class News
{
    private array $news = [
        1 => [
            'id' => 1,
            'title' => 'Спорт новость 1',
            'text' => 'Хорошая  новость',
            'category_id' => 1
        ],
        2 => [
            'id' => 2,
            'title' => 'Спорт новость 2',
            'text' => 'Хорошая  новость',
            'category_id' => 1
        ],
        3 => [
            'id' => 3,
            'title' => 'Спорт новость 3',
            'text' => 'Хорошая новость',
            'category_id' => 1
        ],
        4 => [
            'id' => 4,
            'title' => 'Политика новость 1',
            'text' => 'Хорошая новость',
            'category_id' => 2
        ],
        5 => [
            'id' => 5,
            'title' => 'Политика новость 2',
            'text' => 'Хорошая новость',
            'category_id' => 2
        ],
        6 => [
            'id' => 6,
            'title' => 'Политика новость 3',
            'text' => 'Хорошая новость',
            'category_id' => 2
        ],
        7 => [
            'id' => 7,
            'title' => 'Политика новость 4',
            'text' => 'Хорошая новость',
            'category_id' => 2
        ],
        8 => [
            'id' => 8,
            'title' => 'Общество новость 1',
            'text' => 'Хорошая новость',
            'category_id' => 3
        ],
        9 => [
            'id' => 9,
            'title' => 'Общество новость 2',
            'text' => 'Хорошая новость',
            'category_id' => 3
        ],
        10 => [
            'id' => 10,
            'title' => 'Общество новость 3',
            'text' => 'Хорошая новость',
            'category_id' => 3
        ]
    ];


    /**
     * @return array[]
     */
    public function getNews(): array
    {
        return $this->news;
    }

    public function getNewsOne($slug, $id): ?array
    {
        $category = (new Categories())->getCategoryBySlug($slug);
        if($category) {
            foreach ($this->getNews() as $news) {
                if ($news['category_id'] == $category['id'] && $news['id'] == $id) {
                    return $news;
                }
            }
        }
        return null;
    }

}
