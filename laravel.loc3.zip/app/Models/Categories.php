<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use JetBrains\PhpStorm\Pure;

class Categories extends Model
{
    private array $categories = [
        'Sport' => [
            'id' => 1,
            'title' => 'Спорт',
            'slug' => 'Sport'
        ],
        'Politic' => [
            'id' => 2,
            'title' => 'Политика',
            'slug' => 'Politic'
        ],
        'Society' => [
            'id' => 3,
            'title' => 'Общество',
            'slug' => 'Society'
        ]
    ];


    /**
     * @return array[]
     */
    public function getCategories(): array
    {
        return $this->categories;
    }

    /**
     * @param $id
     * @return array|null
     */
    public function getCategoriesId($id): ?array
    {
        foreach ($this->getCategories() as $item) {
            if ($item['id'] == $id) {
                return $item;
            }
        }
        return null;
    }


    /**
     * @param $slug
     * @return array|null
     */
    public function getCategoryBySlug($slug): ?array
    {
        return $this->getCategories()[$slug] ?? null;
    }

    public function getNewsByCategoriesId($id): ?array
    {
        $news = [];
        $get_news = (new News())->getNews();
        foreach ($get_news as $item) {
            if ($item['category_id'] == $id) {
                $news[] = $item;
            }
        }
        return $news;
    }

    public function getNewsByCategorieSlug($slug): ?array
    {
        $news = [];
        $get_categories = $this->getCategoryBySlug($slug);
        if (!is_null($get_categories)) {
            $get_news = (new News())->getNews();
            foreach ($get_news as $item) {
                if ($item['category_id'] == $get_categories['id']) {
                    $news[] = $item;
                }
            }
        }
        return $news;
    }


}
