<?php

namespace App\Http\Controllers\News;

use App\Http\Controllers\Controller;
use App\Models\News;

use function abort;
use function view;

class NewsController extends Controller
{
    function index(News $news): string
    {

        return view('news')->with('news', $news->getNews());
    }

    function show($slug, $id, News $news)
    {
        $news = $news->getNewsOne($slug, $id);
        return is_null($news) ? abort(404) : view('news.newsOne')->with('news', $news);
    }

}
