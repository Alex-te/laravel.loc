<?php

namespace App\Http\Controllers\News;

use App\Http\Controllers\Controller;
use App\Models\Categories;

use function abort;
use function view;

class CategoriesController extends Controller
{
    function index(Categories $categories)
    {
        $categories = $categories->getCategories();
        return view('news.categories')->with('categories', $categories);
    }

    function show($slug, Categories $categories)
    {
        $category_news = $categories->getNewsByCategorieSlug($slug);
        if (!empty($category_news)) {
            $category_name = $categories->getCategoryBySlug($slug);
            return (isset($category_name['slug']) && $category_name['slug'] == $slug)
                ? view('news.catsOne')
                    ->with('categories', $category_news)
                    ->with('category_name', $category_name ?? 'Без назавания')
                : abort(404);
        }
        return null;
    }
}
