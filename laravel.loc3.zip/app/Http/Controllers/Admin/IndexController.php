<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    function index(){
        return view('admin.index');
    }

    function add_news(){
        return view('admin.add_news');
    }

}
