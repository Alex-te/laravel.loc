<?php

use App\Http\Controllers\Admin\IndexController as AdminIndexController;
use App\Http\Controllers\HomeContraller;
use App\Http\Controllers\News\CategoriesController;
use App\Http\Controllers\News\NewsController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [HomeContraller::class, 'index'])->name('home');


//Route::prefix('news')
//    ->group(function () {
Route::get('/news/categories', [CategoriesController::class, 'index'])
    ->name('news.categories');
Route::get('/news/categories/{id}', [CategoriesController::class, 'show'])
    ->where('id', '[0-9]+')
    ->name('news.catsOne');
Route::get('/news/news', [NewsController::class, 'index'])->name('news');
Route::get('/news/category_{category_id}/{id}', [NewsController::class, 'show'])
    ->where('category_id', '[0-9]+')
    ->where('id', '[0-9]+')
    ->name('news.newsOne');
//    });


Route::name('admin.')
    ->prefix('admin')
//    ->namespace('Admin')
    ->group(function () {
        Route::get('/', [AdminIndexController::class, 'index'])->name('index');
        Route::get('/test1', [AdminIndexController::class, 'test1'])->name('test1');
        Route::get('/test2', [AdminIndexController::class, 'test2'])->name('test2');
    });


Route::view('/about', 'about')->name('about');

Route::view('/auth', 'auth')->name('auth');

//
//Route::get('news/{id}', function ($id = null) {
//    return view('/news');
//})->where('id', '[0-9]+')->name('news');
//
//Route::fallback(function (){ // должна быть последним
//    return view('404');
//});

