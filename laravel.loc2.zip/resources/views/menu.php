<a href="<?= route('home') ?>">Главная</a>
<a href="<?= route('news.categories')?>">Категории новостей</a>
<a href="<?= route('admin.index') ?>">Админка</a>
<a href="<?= route('auth') ?>">Авторизация</a>
<br/>
<br/>
