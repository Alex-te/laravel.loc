<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Авторизация</title>
</head>
<body>
<?php include_once 'menu.php';?>
<form action="post">
    <div>
        <label for="login">Логин</label>
        <input type="text" name="login" id="login">
    </div>
    <div>
        <label for="password">Пароль</label>
        <input type="text" name="password" id="password">
    </div>
    <div>
        <label for="remember_me">Запомнить меня</label>
        <input type="checkbox" name="remember_me" id="remember_me">
    </div>
    <button type="submit">Отправить</button>
</form>
<br/>
<a href="javascript:history.back()">Назад</a>
</body>
</html>
