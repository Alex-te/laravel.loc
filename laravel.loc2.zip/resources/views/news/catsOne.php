
<h2> <?= key($categories) ?></h2>
<?php

foreach ($categories as $category): ?>
    <?php
    foreach ($category as $item): ?>
        <a href="<?= route('news.newsOne', [$item['category_id'], $item['id']]) ?>"><?= $item['title'] ?></a> </br>
    <?php
    endforeach; ?>
<?php
endforeach; ?>
<br/>
<?php include_once 'add_news.php';?>
<br/>
<a href="javascript:history.back()">Назад</a>
