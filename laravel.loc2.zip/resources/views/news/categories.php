<h2>Категории</h2>

<?php foreach ($categories as $item): ?>
    <a href="<?= route('news.catsOne', $item['id'])?>"><?=$item['title']?></a> </br>
<?php endforeach; ?>
<br/>
<a href="javascript:history.back()">Назад</a>
