<h2>Новости</h2>
<?php foreach ($news as $item): ?>
    <a href="<?= route('news.newsOne', $item['id'])?>"><?=$item['title']?></a> </br>
<?php endforeach; ?>

<br/>
<a href="javascript:history.back()">Назад</a>
