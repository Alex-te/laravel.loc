<h2>Добавить новость</h2>
<form action="post">
    <div>
        <label for="title">Заголовок</label>
        <input type="text" name="title" id="title">
    </div>
    <div>
        <label for="news_text">Описание</label>
        <textarea name="news_text" id="news_text"></textarea>
    </div>
    <div>
        <label for="short_news">Краткое описание</label>
        <input type="text" name="short_news" id="short_news">
    </div>
    <button type="submit">Добавить</button>
</form>
