<?php

namespace App\Http\Controllers\News;

use App\Http\Controllers\Controller;
use App\Models\Categories;

use function abort;
use function view;

class CategoriesController extends Controller
{
    function index()
    {
        $categories = Categories::getCategories();
        return view('news.categories')->with('categories', $categories);
    }

    function show($id)
    {
        $categories = Categories::getNewsByCategoriesId($id);
        return is_null($categories) ? abort(404) : view('news.catsOne')->with('categories', $categories);
    }
}
