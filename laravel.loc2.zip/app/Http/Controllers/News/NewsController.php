<?php

namespace App\Http\Controllers\News;

use App\Http\Controllers\Controller;
use App\Models\News;

use function abort;
use function view;

class NewsController extends Controller
{
    function index(): string
    {
        $news = News::getNews();
        return view('news')->with('news', $news);
    }

    function show($category_id, $id)
    {
        $news = News::getNewsOne($category_id, $id);
        return is_null($news) ? abort(404) : view('news.newsOne')->with('news', $news);
    }

}
