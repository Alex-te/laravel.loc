<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use JetBrains\PhpStorm\Pure;

class Categories extends Model
{
    use HasFactory;

    private static $categories = [
        [
            'id' => 1,
            'title' => 'Спорт',
        ],
        [
            'id' => 2,
            'title' => 'Политика'
        ],
        [
            'id' => 3,
            'title' => 'Общество'
        ]
    ];


    /**
     * @return array[]
     */
    public static function getCategories(): array
    {
        return self::$categories;
    }

    /**
     * @param $id
     * @return array|null
     */
    public static function getCategoriesId($id) : ?array
    {
        foreach (self::getCategories() as $item) {
            if ($item['id'] == $id) {
                return $item;
            }
        }
        return null;
    }

    /**
     * @param $id
     * @return array|null
     */
     public static function getNewsByCategoriesId($id): ?array
    {
        $news = [];
        $category_name = self::getCategoriesId($id)['title'];
        foreach (News::getNews() as $item) {
            if ($item['category_id'] == $id) {
                $news[$category_name][] = $item;
            }
        }
        return $news;
    }


}
