<?php

namespace App\Models;

class News
{
    private static $news = [
        [
            'id' => 1,
            'title' => 'Спорт новость 1',
            'text' => 'Хорошая  новость',
            'category_id' => 1
        ],
        [
            'id' => 2,
            'title' => 'Спорт новость 2',
            'text' => 'Хорошая  новость',
            'category_id' => 1
        ],
        [
            'id' => 3,
            'title' => 'Спорт новость 1',
            'text' => 'Хорошая новость',
            'category_id' => 1
        ],
        [
            'id' => 4,
            'title' => 'Политика новость 1',
            'text' => 'Хорошая новость',
            'category_id' => 2
        ],
        [
            'id' => 5,
            'title' => 'Политика новость 2',
            'text' => 'Хорошая новость',
            'category_id' => 2
        ],
        [
            'id' => 6,
            'title' => 'Политика новость 3',
            'text' => 'Хорошая новость',
            'category_id' => 2
        ],
        [
            'id' => 7,
            'title' => 'Политика новость 4',
            'text' => 'Хорошая новость',
            'category_id' => 2
        ],
        [
            'id' => 8,
            'title' => 'Общество новость 1',
            'text' => 'Хорошая новость',
            'category_id' => 3
        ],
        [
            'id' => 9,
            'title' => 'Общество новость 2',
            'text' => 'Хорошая новость',
            'category_id' => 3
        ]
    ];

    /**
     * @return array[]
     */
    public static function getNews(): array
    {
        return self::$news;
    }

    public static function getNewsOne($category_id, $id) : ?array
    {
        foreach (self::getNews() as $news) {
            if ($news['category_id'] == $category_id && $news['id'] == $id) {
                return $news;
            }
        }
        return null;
    }


}
