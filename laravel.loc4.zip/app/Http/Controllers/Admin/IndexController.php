<?php

namespace App\Http\Controllers\Admin;

use App\Exports\NewsExport;
use App\Exports\UsersExport;
use App\Http\Controllers\Controller;
use App\Models\Categories;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;

class IndexController extends Controller
{
    function index()
    {
        return view('admin.index');
    }

    function create(Request $request, Categories $categories)
    {
        if ($request->isMethod('post')) {
//            $request->flash();
//            dd($request->except('_token'));
            $news = json_decode(Storage::disk('local')->get('news.json'), true);
            $id = !empty($news) ? array_key_last($news) + 1 : 0;
            $category_slug = $categories->getCategoriesId($request->except('_token')['category_id'])['slug'];
            $news[] = $request->except('_token');
            $news[$id] += ['id' => $id];
            Storage::disk('local')->put('news.json', json_encode($news, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            return redirect()->route('news.show', [$category_slug, $id]);
        }
        return view('admin.create', ['categories' => $categories->getCategories()]);
    }

    function test1()
    {
        return response()->download('1.png');
    }



    function test2(Request $request, Categories $categories)
    {
        if ($request->isMethod('post')) {
            $news = [];
            foreach ($categories->getNewsByCategoriesId($request->except('_token')['category_id']) as $item) {
                $news[] = [
                    $categories->getCategoriesId($item['category_id'])['title'],
                    $item['title'],
                    $item['text'],
                    (isset($item['isPrivate']) && $item['isPrivate'] == 'on' ? 'да' : 'нет')
                ];
            }
            $export = new NewsExport($news);

            return Excel::download($export, 'news.xlsx');
            /*response()->json($categories->getNewsByCategoriesId($request->except('_token')['category_id']))
            ->header('Content-Disposition', 'attachment; filename=news.json')
            ->setEncodingOptions(JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);*/
        }
        return view('admin.test2', ['categories' => $categories->getCategories()]);
    }

}
