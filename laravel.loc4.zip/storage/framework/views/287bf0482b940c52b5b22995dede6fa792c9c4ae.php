<br>
<a href="javascript:history.back()">Назад</a>
<?php /**PATH D:\OSPanel\domains\laravel.loc\resources\views/back.blade.php ENDPATH**/ ?>