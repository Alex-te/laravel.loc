<?php

return [
    'admin' => [
        'categories' => 10,
        'news' => 10
    ]
];
