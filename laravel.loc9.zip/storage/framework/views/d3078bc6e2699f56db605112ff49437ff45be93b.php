<?php $__env->startSection('content'); ?>
    <h2>Добро пожаловать, <?php echo e(Auth::user()->name); ?></h2>
    <br/>
    <?php if(Auth::user()->avatar): ?>
        <img src="<?php echo e(Auth::user()->avatar); ?>" style="width:200px;">
    <?php endif; ?>
    <br>
    <?php if(Auth::user()->is_admin === true): ?>
    <a href="<?php echo e(route('admin.index')); ?>">В админку</a>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\laravel.loc\resources\views/account/index.blade.php ENDPATH**/ ?>