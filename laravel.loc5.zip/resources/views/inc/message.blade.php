@php
    $message = $type = null;

    if(session()->has('success')){
        $message = session()->get('success');
        $type = "info";
    }

    if(session()->has('error')){
        $message = session()->get('error');
        $type = "warning";
    }
@endphp

@if(!is_null($type) && !is_null($message))
    <div class="alert alert-:type='$type'" role="alert">
       :message="$message"
    </div>
@endif
