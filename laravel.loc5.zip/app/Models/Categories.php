<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use JetBrains\PhpStorm\Pure;

class Categories extends Model
{
//    private array $categories = [
//        'Sport' => [
//            'id' => 1,
//            'title' => 'Спорт',
//            'slug' => 'Sport'
//        ],
//        'Politic' => [
//            'id' => 2,
//            'title' => 'Политика',
//            'slug' => 'Politic'
//        ],
//        'Society' => [
//            'id' => 3,
//            'title' => 'Общество',
//            'slug' => 'Society'
//        ]
//    ];


    public function getCategories()
    {
//        return json_decode(Storage::disk('local')->get('categories.json'), true);
        return DB::table('categories')
            ->select('id', 'title', 'slug')
            ->get();
//            DB::select(
//            'select id,
//                          title,
//                          slug
//                     from categories'
//        );
    }


    public function getCategoriesId($id)
    {
//        foreach ($this->getCategories() as $item) {
//            if ($item['id'] == $id) {
//                return $item;
//            }
//        }
        return DB::table('categories')
            ->select('id', 'title', 'slug')
            ->where('id', '=', $id)
            ->first();

//            DB::selectOne(
//            'select id,
//                         title,
//                         slug
//                    from categories
//                    where :id',
//            ['id' => $id]
//        );
    }


    public function getCategoryBySlug($slug)
    {
        return DB::table('categories')
            ->select('id', 'title', 'slug')
            ->where('slug', '=', $slug)
            ->first();
    }

    public function getNewsByCategoriesId($id)
    {
//        $news = [];
//        $get_news = (new News())->getNews();
//        foreach ($get_news as $item) {
//            if ($item->category_id == $id) {
//                $news[] = $item;
//            }
//        }
        return DB::table('news')
            ->where('category_id', '=', $id)
            ->get();
    }

    public function getNewsByCategorieSlug($slug)
    {
//        $result = [];
//        $get_categories = $this->getCategoryBySlug($slug);
//        if (!is_null($get_categories)) {
//            $get_news = (new News)->getNews();
//            foreach ($get_news as $item) {
//                if ($item->category_id == $get_categories['id']) {
//                    $result[] = $item;
//                }
//            }
//        }
        return DB::table('categories')
            ->select('news.id', 'news.title', 'news.text', 'news.is_private', 'news.category_id')
            ->join('news', 'news.category_id', '=', 'categories.id')
            ->where('categories.slug', '=', $slug)
            ->get();
//        return  DB::select(
//            "select n.id,
//                          n.title,
//                          n.is_private,
//                          n.category_id,
//                          n.text
//                    from categories c
//              inner join news n
//                      on n.category_id = c.id
//                    where c.slug = :slug",
//            ['slug' => $slug]);
    }


}
