<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class News
{
//    private array $news = [
//        1 => [
//            'id' => 1,
//            'title' => 'Спорт новость 1',
//            'text' => 'Хорошая  новость',
//            'category_id' => 1
//        ],
//        2 => [
//            'id' => 2,
//            'title' => 'Спорт новость 2',
//            'text' => 'Хорошая  новость',
//            'category_id' => 1
//        ],
//        3 => [
//            'id' => 3,
//            'title' => 'Спорт новость 3',
//            'text' => 'Хорошая новость',
//            'category_id' => 1
//        ],
//        4 => [
//            'id' => 4,
//            'title' => 'Политика новость 1',
//            'text' => 'Хорошая новость',
//            'category_id' => 2
//        ],
//        5 => [
//            'id' => 5,
//            'title' => 'Политика новость 2',
//            'text' => 'Хорошая новость',
//            'category_id' => 2
//        ],
//        6 => [
//            'id' => 6,
//            'title' => 'Политика новость 3',
//            'text' => 'Хорошая новость',
//            'category_id' => 2
//        ],
//        7 => [
//            'id' => 7,
//            'title' => 'Политика новость 4',
//            'text' => 'Хорошая новость',
//            'category_id' => 2
//        ],
//        8 => [
//            'id' => 8,
//            'title' => 'Общество новость 1',
//            'text' => 'Хорошая новость',
//            'category_id' => 3
//        ],
//        9 => [
//            'id' => 9,
//            'title' => 'Общество новость 2',
//            'text' => 'Хорошая новость',
//            'category_id' => 3
//        ],
//        10 => [
//            'id' => 10,
//            'title' => 'Общество новость 3',
//            'text' => 'Хорошая новость',
//            'category_id' => 3
//        ]
//    ];


    public function getNews()
    {
        // чтение из файла
//        return json_decode(Storage::disk('local')->get('news.json'), true);
        return DB::table('news')
            ->select('id', 'title', 'is_private', 'category_id');

//            DB::select(
//            'select id,
//                          title,
//                          slug,
//                          is_private,
//                          category_id
//                     from news'
//        );
    }

    public function getNewsById($id)
    {
        return DB::table('news')
            ->select('id', 'title',  'is_private', 'category_id')
            ->where('id', '=', $id )
            ->first();
    }


    public function save($news): bool
    {
        return Storage::disk('local')->put('news.json', json_encode($news, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }

    public function insert($news){

        return DB::table('news')->insertGetId($news);
    }

    /**
     * @param $slug
     * @param $id
     * @return \Illuminate\Database\Eloquent\Model|\Illuminate\Database\Query\Builder|object|null
     */
    public function getNewsOne($slug, $id)
    {
//        $category = (new Categories())->getCategoryBySlug($slug);
//        if ($category) {
//            foreach ($this->getNews() as $news) {
//                if ($news['category_id'] == $category['id'] && $news['id'] == $id) {
//                    return $news;
//                }
//
//                if ($news->category_id == $category['id'] && $news->id == $id) {
//                    return $news;
//                }
//            }
        return DB::table('categories')
            ->select('news.id', 'news.title', 'news.is_private', 'news.category_id', 'news.text')
            ->join('news', function ($join) use ($id) {
                $join->on('news.category_id', '=', 'categories.id')
                    ->where('news.id', $id);
            })
            ->where('categories.slug', '=', $slug)
            ->first();
//        return DB::selectOne(
//            'select n.id,
//                          n.title,
//                          n.is_private,
//                          n.category_id,
//                          n.text
//                    from categories c
//              inner join news n
//                      on n.category_id = c.id
//                     and n.id = :id
//                    where c.slug = :slug',
//            ['slug' => $slug, 'id' => $id]
//        );
//        }
//        return null;
    }

}
