<?php

namespace App\Http\Controllers\News;

use App\Http\Controllers\Controller;
use App\Models\Categories;
use App\Models\News;

use function abort;
use function view;

class NewsController extends Controller
{
    function index(News $news): string
    {

        return view('news')->with('news', $news->getNews());
    }

    function show($slug, $id, News $news, Categories $categories)
    {
        $news = $news->getNewsOne($slug, $id);

        return is_null($news) ?
            abort(404) :
            view('news.show')
                ->with('news', $news)
                ->with('category', $categories->getCategoryBySlug($slug));
    }

}
