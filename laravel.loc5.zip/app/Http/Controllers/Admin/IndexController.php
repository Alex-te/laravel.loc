<?php

namespace App\Http\Controllers\Admin;

use App\Exports\NewsExport;
use App\Exports\UsersExport;
use App\Http\Controllers\Controller;
use App\Models\Categories;
use App\Models\News;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;

class IndexController extends Controller
{
    function index()
    {
        return view('admin.index');
    }

    function _create(Request $request, Categories $categories, News $news)
    {
        if ($request->isMethod('post')) {
//            $request->flash();
//            dd($request->except('_token'));
            $getNews = json_decode(Storage::disk('local')->get('news.json'), true);
            $category_slug = $categories->getCategoriesId($request->except('_token')['category_id'])['slug'];

            $getNews[] = $request->except('_token');
            $id = array_key_last($getNews);
            !isset($getNews[array_key_last($getNews)]['is_private'])
                ? $getNews[array_key_last($getNews)]['is_private'] = false
                : $getNews[array_key_last($getNews)]['is_private'] = true;
            $getNews[array_key_last($getNews)] += ['id' => $id];
            return $news->save($getNews) ? redirect()->route('news.show', [$category_slug, $id]) : abort(404);
        }
        return view('admin.create', ['categories' => $categories->getCategories()]);
    }

    function create(Request $request, Categories $categories, News $news)
    {
        if ($request->isMethod('post')) {
            $getNews = $request->except('_token');
            !isset($getNews['is_private'])
                ? $getNews['is_private'] = false
                : $getNews['is_private'] = true;
            $id_news = $news->insert($getNews);
            if (!empty($id_news)) {
                $insert_news = $news->getNewsById($id_news);
                $category_slug = $categories->getCategoriesId($insert_news->category_id)->slug;
                return redirect()->route('news.show', [$category_slug, $insert_news->id]);
            } else {
                return abort(404);
            }
        }
        return view('admin.create', ['categories' => $categories->getCategories()]);
    }

    function test1()
    {
        return response()->download('1.png');
    }


    function test2(Request $request, Categories $categories)
    {
        if ($request->isMethod('post')) {
            $news = [];
            foreach ($categories->getNewsByCategoriesId($request->except('_token')['category_id']) as $item) {
                $news[] = [
                    $categories->getCategoriesId($item->category_id)->title,
                    $item->title,
                    $item->text,
                    ($item->is_private ? 'да' : 'нет')
                ];
            }
            $export = new NewsExport($news);

            return Excel::download($export, 'news.xlsx');
            /*response()->json($categories->getNewsByCategoriesId($request->except('_token')['category_id']))
            ->header('Content-Disposition', 'attachment; filename=news.json')
            ->setEncodingOptions(JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);*/
        }
        return view('admin.test2', ['categories' => $categories->getCategories()]);
    }

}
