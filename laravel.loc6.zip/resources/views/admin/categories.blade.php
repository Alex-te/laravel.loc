@extends('layouts.main')

@section('title')
    @parent | Категории@endsection

@section('menu')
    @include('admin.menu')
@endsection

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><h2>{{ __('Категории') }}</h2></div>
                    <div class="card-body">
                        @include('inc.message')
                        <div class="row mb-3">
                            <div class="form-group">
                                <a href="{{route('admin.category_single', ['id'])}}" class="btn btn-primary" > Добавить</a>
                            </div>
                        </div>
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col">Название</th>
                                <th scope="col">Действия</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($categories as $item)
                            <tr>
                                <td>{{$item->title}}</td>
                                <td><a href="{{route('admin.category_single', ['id' => $item->id])}}">Ред.</a>
                                    <a href="{{route('admin.category_remove', ['id' => $item->id])}}">Удал.</a></td>
                            </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    @include('back')
@endsection
