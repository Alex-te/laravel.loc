@extends('layouts.main')

@section('title')
    @parent | Источники новостей@endsection

@section('menu')
    @include('admin.menu')
@endsection

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><h2>{{ __('Источники новостей') }}</h2></div>
                    <div class="card-body">
                        @include('inc.message')
                        <div class="row mb-3">
                            <div class="form-group">
                                <a href="{{route('admin.news_sources_single', ['id'])}}" class="btn btn-primary" > Добавить</a>
                            </div>
                        </div>
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col">Название</th>
                                <th scope="col">URL</th>
                                <th scope="col">Описание</th>
                                <th scope="col">Действия</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($sources as $item)
                            <tr>
                                <td>{{$item->name}}</td>
                                <td>{{$item->url}}</td>
                                <td>{{substr($item->description,0, 50)}}...</td>
                                <td><a href="{{route('admin.news_sources_single', ['id' => $item->id])}}">Ред.</a>
                                    <a href="{{route('admin.news_source_remove', ['id' => $item->id])}}">Удал.</a></td>
                            </tr>
                            @endforeach
                            </tbody>
                        </table>


                    </div>
                </div>
            </div>
        </div>

    @include('back')
@endsection
