<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Categories;
use App\Queries\CategoriesQueryBuilder;
use Illuminate\Http\Request;

class CategoriesController extends Controller
{

    function CategoriesShow(CategoriesQueryBuilder $builder)
    {
        return view('admin.categories', [
            'categories' => $builder->getCategories()
        ]);
    }

    function CategoryCreate(Request $request, CategoriesQueryBuilder $builder)
    {
        $news = $builder->insert($request->except('_token'));
        if (!empty($news)) {
            return redirect()->route('admin.categories')
                ->with('success', 'Категория отредактирована ');
        } else {
            return redirect()->back()
                ->with('error', 'Ошибка редактирования');
        }
    }

    function CategorySingle(CategoriesQueryBuilder $builder, $id)
    {
        return view('admin.category', [
            'category' => $builder->getCategoryById($id)
        ]);
    }

    function CategoryUpdate(Request $request, CategoriesQueryBuilder $builder, $id)
    {
        if ($builder->update($id, $request->except('_token'))) {
            return redirect()->route('admin.categories')
                ->with('success', 'Категория отредактирована ');
        } else {
            return redirect()->back()
                ->with('error', 'Ошибка редактирования');
        }
    }

    function CategoryRemove(CategoriesQueryBuilder $builder, $id)
    {
        if ($builder->remove($id)) {
            return redirect()->route('admin.categories')
                ->with('success', 'Категория удалена');
        } else {
            return redirect()->back()
                ->with('error', 'Ошибка удаления');
        }
    }
}
