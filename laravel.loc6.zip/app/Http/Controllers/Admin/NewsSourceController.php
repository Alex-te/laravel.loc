<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Queries\NewsSourcesQueryBuilder;
use Illuminate\Http\Request;

class NewsSourceController extends Controller
{

    function NewsSourcesShow(NewsSourcesQueryBuilder $builder)
    {
        return view('admin.news_sources_show', ['sources' => $builder->getNewsSources()]);
    }


    function NewsSourceCreate(Request $request, NewsSourcesQueryBuilder $builder)
    {
        $newsSourse = $builder->insert($request->except('_token'));
        if (!empty($newsSourse)) {
            return redirect()->route('admin.news_sources_show', [$newsSourse->id]);
        } else {
            return redirect()->back()
                ->with('error', 'Ошибка редактирования');
        }
    }

    function NewsSourceUpdate(Request $request, NewsSourcesQueryBuilder $builder, $id)
    {
        if ($builder->update($id, $request->except('_token'))) {
            return redirect()->route('admin.news_sources_show')
                ->with('success', 'Новость отредактирована ');
        } else {
            return redirect()->back()
                ->with('error', 'Ошибка редактирования');
        }
    }

    function NewsSourcesSingle(NewsSourcesQueryBuilder $builder, $id)
    {
        return view('admin.news_source', [
            'news_source' => $builder->getNewsSourceById($id)
        ]);
    }

    function NewsSourceRemove(NewsSourcesQueryBuilder $builder, $id)
    {
        if ($builder->remove($id)) {
            return redirect()->route('admin.news_sources_show')
                ->with('success', 'Источник удален');
        } else {
            return redirect()->back()
                ->with('error', 'Ошибка удаления');
        }
    }
}
