<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Categories;
use App\Models\NewsSources;
use App\Queries\CategoriesQueryBuilder;
use App\Queries\NewsQueryBuilder;
use App\Queries\NewsSourcesQueryBuilder;
use Illuminate\Http\Request;

class NewsController extends Controller
{

    private function getNewsData($request)
    {
        $getNews = $request->except('_token');
        !isset($getNews['is_private'])
            ? $getNews['is_private'] = false
            : $getNews['is_private'] = true;
        return $getNews;
    }


    function NewsCreate(Request $request,  NewsQueryBuilder $builder, CategoriesQueryBuilder $categories)
    {
        $news = $builder->insert($this->getNewsData($request));
        if (!empty($news)) {
            $category_slug = $categories->getCategoryById($news->category_id)->slug;
            return redirect()->route('news.show', [$category_slug, $news->id]);
        } else {
            return redirect()->route('admin.news');
        }
    }


    function NewsSingle(CategoriesQueryBuilder $categories, NewsSourcesQueryBuilder $newsSource, NewsQueryBuilder $builder, $id)
    {
        return view('admin.create', [
            'categories' => $categories->getCategories(),
            'news' => $builder->getNewsById($id),
            'newsSource' => $newsSource->getNewsSources()
        ]);
    }

    function NewsShow(NewsQueryBuilder $builder, CategoriesQueryBuilder $categories, NewsSourcesQueryBuilder $newsSources)
    {
        return view('admin.news', [
            'news' => $builder->getNews(),
            'categories' => $categories->getCategories(),
            'newsSources' => $newsSources->getNewsSources()
        ]);
    }


    function NewsUpdate(Request $request, NewsQueryBuilder $builder, $id)
    {
        if ($builder->update($id, $this->getNewsData($request))) {
            return redirect()->route('admin.news')
                ->with('success', 'Новость отредактирована ');
        } else {
            return redirect()->back()
                ->with('error', 'Ошибка редактирования');
        }
    }

    function NewsRemove(NewsQueryBuilder $builder, $id)
    {
        if ($builder->remove($id)) {
            return redirect()->route('admin.news')
                ->with('success', 'Новость удалена ');
        } else {
            return redirect()->back()
                ->with('error', 'Ошибка удаления');
        }
    }
}
