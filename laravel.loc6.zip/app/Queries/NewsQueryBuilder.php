<?php

namespace App\Queries;

use App\Models\News;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;

final class NewsQueryBuilder
{
    private Builder $model;

    public function __construct()
    {
        $this->model = News::query();
    }

    private function paginate($items, $perPage = 5, $page = null, $options = [])
    {
        $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);
        $items = $items instanceof Collection ? $items : Collection::make($items);
        return new LengthAwarePaginator($items->forPage($page, $perPage), $items->count(), $perPage, $page, $options);
    }

    public function getNews(): Collection|LengthAwarePaginator
    {
        return
            $this->paginate($this->model->get()->sortByDesc('id'),config('pagination.admin.news'));
//            $this->model
//            ->paginate(config('pagination.admin.news'));
    }

    public function getNewsById($id)
    {
        return $this->model
            ->where('id', '=', $id)
            ->first();
    }

    public function insert(array $data)
    {
        return $this->model->create($data);
    }

    public function update($id, array $data)
    {
        return $this->getNewsById($id)->fill($data)->save();
    }

    public function remove($id)
    {
        return $this->getNewsById($id)->delete();
    }
}
