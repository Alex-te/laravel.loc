<?php

use App\Http\Controllers\Admin\IndexController as AdminIndexController;
use App\Http\Controllers\Admin\NewsSourceController;
use App\Http\Controllers\Admin\NewsController as AdminNewsController;
use App\Http\Controllers\Admin\CategoriesController as AdminCategoriesController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\News\CategoriesController;
use App\Http\Controllers\News\NewsController;
use Illuminate\Support\Facades\Route;



Route::get('/', [HomeController::class, 'index'])->name('home');

Route::get('/save', [HomeController::class, 'save'])->name('save');


Route::prefix('news')
    ->group(function () {
Route::get('/categories', [CategoriesController::class, 'index'])
    ->name('news.categories');
Route::get('/categories/{slug}', [CategoriesController::class, 'show'])
//    ->where('id', '[0-9]+')
    ->name('news.catsOne');
Route::get('/news', [NewsController::class, 'index'])->name('news');
Route::get('/{slug}/{id}', [NewsController::class, 'show'])
    ->where('category_id', '[0-9]+')
    ->where('id', '[0-9]+')
    ->name('news.show');
    });


Route::name('admin.')
    ->prefix('admin')
//    ->namespace('Admin')
    ->group(function () {
        Route::get('/', [AdminIndexController::class, 'index'])->name('index');
        Route::match(['get', 'post'],'/categories_show', [AdminCategoriesController::class, 'CategoriesShow'])->name('categories');
        Route::match(['get', 'post'],'/category_single/{id}', [AdminCategoriesController::class, 'CategorySingle'])->name('category_single');
        Route::match(['get', 'post'],'/category_update/{id}', [AdminCategoriesController::class, 'CategoryUpdate'])->name('category_update');
        Route::match(['get', 'post'],'/category_create', [AdminCategoriesController::class, 'CategoryCreate'])->name('category_create');
        Route::match(['get', 'post'],'/category_remove/{id}', [AdminCategoriesController::class, 'CategoryRemove'])->name('category_remove');

        Route::match(['get', 'post'],'/news_show', [AdminNewsController::class, 'NewsShow'])->name('news');
        Route::match(['get', 'post'],'/news_single/{id}', [AdminNewsController::class, 'NewsSingle'])->name('news_single');
        Route::match(['get', 'post'],'/news_update/{id}', [AdminNewsController::class, 'NewsUpdate'])->name('news_update');
        Route::match(['get', 'post'],'/news_create', [AdminNewsController::class, 'NewsCreate'])->name('create');
        Route::match(['get', 'post'],'/news_remove/{id}', [AdminNewsController::class, 'NewsRemove'])->name('remove');

        Route::match(['get', 'post'], '/news_sources_show',[NewsSourceController::class, 'NewsSourcesShow'])->name('news_sources_show');
        Route::match(['get', 'post'], '/news_sources_single/{id}',[NewsSourceController::class, 'NewsSourcesSingle'])->name('news_sources_single');
        Route::match(['get', 'post'], '/news_source_update/{id}',[NewsSourceController::class, 'NewsSourceUpdate'])->name('news_source_update');
        Route::match(['get', 'post'], '/news_source_create',[NewsSourceController::class, 'NewsSourceCreate'])->name('news_source');
        Route::match(['get', 'post'],'/news_source_remove/{id}', [NewsSourceController::class, 'NewsSourceRemove'])->name('news_source_remove');

        Route::get('/test1', [AdminIndexController::class, 'test1'])->name('test1');
        Route::match(['get', 'post'], '/test2',[AdminIndexController::class, 'test2'])->name('test2');
    });


Route::view('/about', 'about')->name('about');

Route::view('/auth', 'auth')->name('auth');

//
//Route::get('news/{id}', function ($id = null) {
//    return view('/news');
//})->where('id', '[0-9]+')->name('news');
//
//Route::fallback(function (){ // должна быть последним
//    return view('404');
//});


Auth::routes();

//Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
