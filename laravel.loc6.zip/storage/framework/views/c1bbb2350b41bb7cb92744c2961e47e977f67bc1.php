<?php
    $message = $type = null;

    if(session()->has('success')){
        $message = session()->get('success');
        $type = "primary";
    }

    if(session()->has('error')){
        $message = session()->get('error');
        $type = "danger";
    }
?>

<?php if(!is_null($type) && !is_null($message)): ?>
    <div class="alert alert-<?php echo e($type); ?>" role="alert">
        <?php echo e($message); ?>

    </div>
<?php endif; ?>
<?php /**PATH D:\OSPanel\domains\laravel.loc\resources\views/inc/message.blade.php ENDPATH**/ ?>