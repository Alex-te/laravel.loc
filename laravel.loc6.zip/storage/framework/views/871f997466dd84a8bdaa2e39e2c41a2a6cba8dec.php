<?php $__env->startSection('title'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> | <?php if(isset($news_source)): ?>Редактировать <?php else: ?> Добавить <?php endif; ?>источник новостей<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><h2><?php if(isset($news_source)): ?>Редактировать <?php else: ?> Добавить <?php endif; ?>источник
                            новостей</h2></div>
                    <div class="card-body">
                        <form method="POST"
                              action="<?php if(isset($news_source)): ?><?php echo e(route('admin.news_source_update', ['id' => $news_source->id])); ?>

                              <?php else: ?>
                              <?php echo e(route('admin.news_source')); ?>

                              <?php endif; ?>">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($news_source)): ?><input type="hidden" name="id" value="<?php echo e($news_source->id); ?>"><?php endif; ?>
                            <div class="row mb-3">
                                <div class="form-group">
                                    <label for="name" class="form-label">Заголовок источника новостей</label>
                                    <input type="text" class="form-control" name="name" id="name"
                                           value="<?php echo e(old('name')); ?> <?php if(isset($news_source)): ?><?php echo e($news_source->name); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="form-group">
                                    <label for="url" class="form-label">URL источник</label>
                                    <input type="text" class="form-control" name="url" id="url"
                                           value="<?php echo e(old('url')); ?><?php if(isset($news_source)): ?><?php echo e($news_source->url); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="form-group">
                                    <label class="form-check-label" for="description">Текст новости</label>
                                    <textarea name="description" class="form-control"
                                              id="description"><?php echo e(old('description')); ?> <?php if(isset($news_source)): ?><?php echo e($news_source->description); ?><?php endif; ?></textarea>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="form-group">
                                    <button class="btn btn-primary" type="submit"><?php if(isset($news_source)): ?>Редактировать <?php else: ?>
                                            Добавить<?php endif; ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    <?php echo $__env->make('back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\laravel.loc\resources\views/admin/news_source.blade.php ENDPATH**/ ?>