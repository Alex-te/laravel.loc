<?php $__env->startSection('title'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> | Авторизация<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="post">
    <div class="mb-3">
        <label class="form-label" for="login">Логин</label>
        <input class="form-control"  type="text" name="login" id="login">
    </div>
    <div class="mb-3">
        <label class="form-label" for="password">Пароль</label>
        <input class="form-control"  type="text" name="password" id="password">
    </div>
    <div class="mb-3  form-check">
        <label   class="form-check-label"  for="remember_me">Запомнить меня</label>
        <input  class="form-check-input" type="checkbox" name="remember_me" id="remember_me">
    </div>
    <button class="btn btn-primary" type="submit">Отправить</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\laravel.loc\resources\views/auth.blade.php ENDPATH**/ ?>