<?php $__env->startSection('title'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> | <?php if(isset($news_sources)): ?>Редактировать <?php else: ?> Добавить <?php endif; ?>источник новостей<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><h2><?php if(isset($news_sources)): ?>Редактировать <?php else: ?> Добавить <?php endif; ?>источник
                            новостей</h2></div>
                    <div class="card-body">
                        <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form method="POST"
                              action="<?php if(isset($news_sources)): ?><?php echo e(route('admin.news_sources.update', ['news_source' => $news_sources->id])); ?>

                              <?php else: ?>
                              <?php echo e(route('admin.news_source.store')); ?>

                              <?php endif; ?>">
                            <?php if($news_sources): ?>
                                <?php echo method_field('PUT'); ?>
                            <?php endif; ?>
                                <?php echo csrf_field(); ?>
                            <?php if(isset($news_sources)): ?><input type="hidden" name="id" value="<?php echo e($news_sources->id); ?>"><?php endif; ?>
                            <div class="row mb-3">
                                <div class="form-group">
                                    <label for="name" class="form-label">Заголовок источника новостей</label>
                                    <input type="text" class="form-control" name="name" id="name"
                                           value="<?php echo e(old('name')); ?> <?php if(isset($news_sources)): ?><?php echo e($news_sources->name); ?><?php endif; ?>">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color:red"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="form-group">
                                    <label for="url" class="form-label">URL источник</label>
                                    <input type="text" class="form-control" name="url" id="url"
                                           value="<?php echo e(old('url')); ?><?php if(isset($news_sources)): ?><?php echo e($news_sources->url); ?><?php endif; ?>">
                                    <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color:red"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="form-group">
                                    <label class="form-check-label" for="description">Описание</label>
                                    <textarea name="description" class="form-control"
                                              id="description"><?php echo e(old('description')); ?> <?php if(isset($news_sources)): ?><?php echo e($news_sources->description); ?><?php endif; ?></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color:red"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="form-group">
                                    <button class="btn btn-primary" type="submit"><?php if(isset($news_sources)): ?>
                                            Редактировать <?php else: ?>
                                            Добавить<?php endif; ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    <?php echo $__env->make('back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\laravel.loc\resources\views/admin/news_sources_create.blade.php ENDPATH**/ ?>