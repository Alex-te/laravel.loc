<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('home')); ?>">Главная</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.index')); ?>">Админка</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.users.index')); ?>">Пользователи</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.categories.index')); ?>"> Категории</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.news.index')); ?>"> Новости</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.news_sources.index')); ?>"> Источники новостей</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.test1')); ?>"> Скачать изображение</a></li>
<li class="nav-item"><a class="nav-link"  href="<?php echo e(route('admin.test2')); ?>"> Скачать новости</a></li>
<?php /**PATH D:\OSPanel\domains\laravel.loc\resources\views/admin/menu.blade.php ENDPATH**/ ?>