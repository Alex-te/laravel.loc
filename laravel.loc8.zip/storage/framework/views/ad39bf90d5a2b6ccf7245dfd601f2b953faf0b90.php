<li class="nav-item">
    <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Главная</a>
</li>
<li class="nav-item">
    <a class="nav-link <?php echo e(request()->routeIs('news.categories') ? 'active' : ''); ?>" href="<?php echo e(route('news.categories')); ?>">Категории новостей</a>
</li>
<li class="nav-item">
    <a class="nav-link <?php echo e(request()->routeIs('admin.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.index')); ?>">Админка</a>
</li>
<li class="nav-item">
    <a class="nav-link <?php echo e(request()->routeIs('login') ? 'active' : ''); ?>" href="<?php echo e(route('login')); ?>">Авторизация</a>
</li>

<?php /**PATH D:\OSPanel\domains\laravel.loc\resources\views/menu.blade.php ENDPATH**/ ?>