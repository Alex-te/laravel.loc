<li class="nav-item"><a class="nav-link"  href="{{ route('home')}}">Главная</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.index')}}">Админка</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.users.index')}}">Пользователи</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.categories.index')}}"> Категории</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.news.index')}}"> Новости</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.news_sources.index')}}"> Источники новостей</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.test1')}}"> Скачать изображение</a></li>
<li class="nav-item"><a class="nav-link"  href="{{ route('admin.test2')}}"> Скачать новости</a></li>
